#Script for Goal 1 by Harshita Jhavar
#Creating Story Graph from knowledge base and querying it
setwd("/home/expectopatronum/Desktop/thesis/thesis")
kb_g1 = read.csv("Final_goal1.csv")  # read csv file
kb_g2 = read.csv("thesis_g2.csv")  # read csv file
kb_original = read.csv("td_no_labels.csv")  # read csv file
kb_test = read.csv("thesis_g2_test.csv") #read csv file for sentences
kb_test_final = read.csv("thesis_test_score.csv")

#Loading the libraries
library(dplyr)
library(tidyverse)

#Exploratory analysis of data in the data frame to combine the different categories to Happy, Sad, Angry, Other.

#Adding up the scores
#Training Input 
kb_g1$happy_score = kb_g1$joy + kb_g1$trust + kb_g1$surprise
kb_g1$anger_score = kb_g1$anger + kb_g1$disgust
kb_g1$sad_score = kb_g1$sadness
kb_g1$others_score = kb_g1$anticipation 

#Test Input
kb_test_final$happy_score = kb_test_final$joy + kb_test_final$trust + kb_test_final$surprise
kb_test_final$anger_score = kb_test_final$anger + kb_test_final$disgust
kb_test_final$sad_score = kb_test_final$sadness
kb_test_final$others_score = kb_test_final$anticipation 

#Removing the 7 emotion category scores and creating a new data frame for training including the associated actions
kb_train = data.frame(kb_g1$paragraph, kb_g1$happy_score, kb_g1$anger_score, kb_g1$sad_score, kb_g1$others_score, kb_g1$nrc_sentiment,kb_g1$Valence, kb_g1$Arousal, kb_g1$Dominance, kb_g2$Subject.Characters, kb_g2$Actions.with.Subject.Charcater, kb_g2$Object.Characters, kb_g2$Objects.and.Actions, kb_g1$True.Label)

#Performing chi Square on given data
#Paragraph vs True Label
chisq_paragraph_vs_TrueLabel <- chisq.test(kb_train$kb_g1.paragraph, kb_train$kb_g1.True.Label)
#Happy Score vs True Label
chisq_happy_vs_TrueLabel <- chisq.test(kb_train$kb_g1.happy_score, kb_train$kb_g1.True.Label)
#Sad Score vs True Label
chisq_sad_vs_TrueLabel <- chisq.test(kb_train$kb_g1.sad_score, kb_train$kb_g1.True.Label)

#Angry Score vs True Label
chisq_angry_vs_TrueLabel <- chisq.test(kb_train$kb_g1.anger_score, kb_train$kb_g1.True.Label)

#Other Score vs True Label
chisq_other_vs_TrueLabel <- chisq.test(kb_train$kb_g1.others_score, kb_train$kb_g1.True.Label)

#Explore the top 25 contributors for the given labels
head(chisq_paragraph_vs_TrueLabel$observed, n=25)

#Visualize the contribution
library(corrplot)
corrplot(chisq_paragraph_vs_TrueLabel$residuals, is.cor = FALSE, title = "Paragraph vs True Label")
corrplot(chisq_happy_vs_TrueLabel$residuals, is.cor = FALSE, title = "Happy Score vs True Label")
corrplot(chisq_sad_vs_TrueLabel$residuals, is.cor = FALSE, title = "Sad Score vs True Label")
corrplot(chisq_angry_vs_TrueLabel$residuals, is.cor = FALSE, title = "Angry Score vs True Label")
corrplot(chisq_other_vs_TrueLabel$residuals, is.cor = FALSE, title = "Other Score vs True Label")

#Removing the paragraph column and adding a new data frame to train the model according to emocontext script
norm_div <- kb_g1$happy_score + kb_g1$anger_score + kb_g1$sad_score + kb_g1$others_score
#kb_g3 <- data.frame(kb_original$id, kb_original$turn1, kb_original$turn2, kb_original$turn3, kb_g1$happy_score/norm_div, kb_g1$anger_score/norm_div, kb_g1$sad_score/norm_div, kb_g1$others_score/norm_div, kb_g1$nrc_sentiment,kb_g1$Valence, kb_g1$Arousal, kb_g1$Dominance, kb_g2$Subject.Characters, kb_g2$Actions.with.Subject.Charcater, kb_g2$Object.Characters, kb_g2$Objects.and.Actions, kb_g1$True.Label)

#kb_g3 <- data.frame(kb_original$id, kb_original$turn1, kb_original$turn2, kb_original$turn3, 
#                    kb_g1$happy_score/norm_div, kb_g1$anger_score/norm_div, 
#                    kb_g1$sad_score/norm_div, kb_g1$others_score/norm_div, 
#                    kb_g1$nrc_sentiment, kb_g1$True.Label)

#kb_g3 <- data.frame(kb_original$id, kb_original$turn1, kb_original$turn2, kb_original$turn3, kb_g1$nrc_sentiment,kb_g2$Actions.with.Subject.Charcater, kb_g2$Objects.and.Actions, kb_g1$True.Label)
kb_g3 <- data.frame(kb_original$id, kb_original$turn1, kb_original$turn2, kb_original$turn3, kb_g1$nrc_sentiment, kb_g1$True.Label)
kb_g3[is.na(kb_g3)] <- 0
norm_div_test <- kb_test_final$happy_score + kb_test_final$anger_score + kb_test_final$sad_score + kb_test_final$others_score

#Setting up current test file
#kb_current_test <- data.frame(kb_test$id, kb_test$turn1, kb_test$turn2, kb_test$turn3, kb_test_final$happy_score, kb_test_final$anger_score, kb_test_final$sad_score, kb_test_final$others_score, kb_test_final$nrc_sentiment, kb_test_final$Valence, kb_test_final$Arousal, kb_test_final$Dominance, kb_test$Subject.Characters, kb_test$Actions.with.Subject.Charcater, kb_test$Object.Characters, kb_test$Objects.and.Actions)
#kb_current_test <- data.frame(kb_test$id, kb_test$turn1, kb_test$turn2, kb_test$turn3, 
#                              kb_test_final$happy_score/norm_div_test, kb_test_final$anger_score/norm_div_test, 
#                              kb_test_final$sad_score/norm_div_test, kb_test_final$others_score/norm_div_test, 
#                              kb_test_final$nrc_sentiment)

#kb_current_test <- data.frame(kb_test$id, kb_test$turn1, kb_test$turn2, kb_test$turn3, 
#                              kb_test_final$nrc_sentiment,
#                              kb_test$Actions.with.Subject.Charcater, kb_test$Objects.and.Actions)
kb_current_test <- data.frame(kb_test$id, kb_test$turn1, kb_test$turn2, kb_test$turn3, kb_test_final$nrc_sentiment)
kb_current_test[is.na(kb_current_test)] <- 0
#Exporting the goal 3 corpus to text file
write.table(kb_g3, file = "/home/expectopatronum/Desktop/emoContext/starterkitdata/train5.txt", 
            append = FALSE, sep = "\t", row.names=FALSE, quote=FALSE, fileEncoding = "UTF-8")
#Exporting the goal 3 corpus to text file
write.table(kb_current_test, file = "/home/expectopatronum/Desktop/emoContext/starterkitdata/test5.txt", 
            append = FALSE, sep = "\t", row.names=FALSE, quote=FALSE, fileEncoding = "UTF-8")
#Checking the accuracy
#gold_corpus <- read.csv("/home/expectopatronum/Desktop/emoContext/devsetwithlabels/dev.txt", sep = "\t")
#test_results <- read.csv("/home/expectopatronum/Desktop/emoContext/starting_kit/test.txt", sep = "\t")
#(gold_corpus$label, test_results$label)
