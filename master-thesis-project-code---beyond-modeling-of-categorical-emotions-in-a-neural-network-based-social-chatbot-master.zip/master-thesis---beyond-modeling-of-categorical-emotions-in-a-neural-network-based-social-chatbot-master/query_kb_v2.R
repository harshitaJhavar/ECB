#Script for Goal 2 by Harshita Jhavar
#Creating Story Graph from knowledge base and querying it
setwd("/home/expectopatronum/Desktop/thesis/thesis")
#Corpus created in /home/expectopatronum/Desktop/Thesis_Goal2/WWW_demo-master
library(igraph)
library(stringr)
library(dplyr)
library(tidytext)
library("tm")
library("SnowballC")
#library("wordcloud")
library("RColorBrewer")

#Do not forget to replace the variable name for test file
kb_g2 = read.csv("thesis_g2.csv")  # read csv file
kb_g2_test = read.csv("thesis_g2_test_python.csv") #read csv file
#Preprocessing
#Cleaning Actions and Objects column
preProcess <- function(data){
  data <-  gsub('\\[', '', data)
  data <-  gsub('\\]', '', data)
  data <-  gsub("\\'", '', data)
  data <-  gsub("\\,", '', data)
  data <-  gsub("\\- |\\-| ", ' ', data)
  data <- sub("^$", "NA", data)
  return(data)
}

kb_g2$Subject.Characters <- preProcess(kb_g2$Subject.Characters)
kb_g2$Actions.with.Subject.Charcater <- preProcess(kb_g2$Actions.with.Subject.Charcater)
kb_g2$Object.Characters <- preProcess(kb_g2$Object.Characters)
kb_g2$Objects.and.Actions <- preProcess(kb_g2$Objects.and.Actions)

#Removing those rows in which subject and object both are NA
#RemoveThesis#kb_g2 <- subset(kb_g2, !(grepl("NA",kb_g2[[2]]) & grepl("NA",kb_g2[[4]])))

#Write these event sentences in a csv
anger = 1:length(kb_g2$Sentence) #Will be addressed in next function
anticipation=1:length(kb_g2$Sentence)
disgust=1:length(kb_g2$Sentence)
fear=1:length(kb_g2$Sentence)
joy=1:length(kb_g2$Sentence)
sadness=1:length(kb_g2$Sentence)
surprise=1:length(kb_g2$Sentence)
trust=1:length(kb_g2$Sentence)
paragraph = as.character(1:length(kb_g2$Sentence))
sentence_id = 1:length(kb_g2$Sentence)
nrc_sentiment = 1:length(kb_g2$Sentence)
no_of_interactions = 1:length(kb_g2$Sentence)
Valence =  1:length(kb_g2$Sentence)
Arousal =  1:length(kb_g2$Sentence)
Dominance =  1:length(kb_g2$Sentence)
export = data.frame(paragraph,nrc_sentiment,no_of_interactions,sentence_id,joy,anticipation,surprise,trust,anger,sadness,disgust,fear,Valence, Arousal, Dominance, stringsAsFactors=FALSE)

for(i in 1:length(kb_g2$Sentence)){
  export$paragraph[i] =as.character(kb_g2$Sentence[i])
  #print(kb_g2$Sentence[i])
  export$sentence_id[i] = i
}
#write.csv(export$paragraph, file= "event_distribution.csv", row.names = FALSE)

#Emotion Labelling per event based on the sentences per event

library(syuzhet)
for(i in 1:length(kb_g2$Sentence)){
  print(i)
my_example_text <- export$paragraph[i]
s_v <- get_sentences(export$paragraph[i])
syuzhet_vector <- get_sentiment(s_v, method="syuzhet")
bing_vector <- get_sentiment(s_v, method="bing")
afinn_vector <- get_sentiment(s_v, method="afinn")
nrc_vector <- get_sentiment(s_v, method="nrc")
#Because the different methods use different scales, it may be more useful to compare them 
#using R’s built in sign function. The sign function converts all positive number to 1, all
#negative numbers to -1 and all zeros remain 0.
rbind(
  sign(head(syuzhet_vector)),
  sign(head(bing_vector)),
  sign(head(afinn_vector)),
  sign(head(nrc_vector))
)
#Summing the values in order to get a measure of the overall emotional valence in the text

#Sentiment Plotting
s_v_sentiment <- get_sentiment(s_v)
#Plotting valence for each individual event separately
#plot(
#  s_v_sentiment, 
#  type="l", 
#  main=c("Event ", i ," Plot Trajectory"), 
#  xlab = "Narrative Time", 
#  ylab= "Emotional Valence"
#)

#Emotion Labelling
nrc_data <- get_nrc_sentiment(s_v)
#Which sentences give anger
#angry_items <- which(nrc_data$anger > 0)
#s_v[angry_items]
#Which sentences give joy
#joy_items <- which(nrc_data$joy > 0)
#s_v[joy_items]

#Viewing all emotions and its values in a event
pander::pandoc.table(nrc_data[, 1:8], split.table = Inf)

#Plotting all emotions bar-plot per event
#barplot(
#  sort(colSums(prop.table(nrc_data[, 1:8]))), 
#  horiz = TRUE, 
#  cex.names = 0.7, 
#  las = 1, 
#  main = c("Emotions in Event", i) , xlab="Percentage"
#)

export$anger[i] <- colSums(prop.table(nrc_data[, 1:8]))[1]
export$anticipation[i] <- colSums(prop.table(nrc_data[, 1:8]))[2]
export$disgust[i] <- colSums(prop.table(nrc_data[, 1:8]))[3]
export$fear[i] <- colSums(prop.table(nrc_data[, 1:8]))[4]
export$joy[i] <- colSums(prop.table(nrc_data[, 1:8]))[5]
export$sadness[i] <- colSums(prop.table(nrc_data[, 1:8]))[6]
export$surprise[i] <- colSums(prop.table(nrc_data[, 1:8]))[7]
export$trust[i] <- colSums(prop.table(nrc_data[, 1:8]))[8]

if(length(get_sentiment(get_sentences(export$paragraph[i])))>1)
  export$nrc_sentiment[i] = mean(get_sentiment(get_sentences(export$paragraph[i])))
else
  export$nrc_sentiment[i] =  get_sentiment(get_sentences(export$paragraph[i]))
export$no_of_interactions[i] = length(get_sentiment(get_sentences(export$paragraph[i])))
#Calculating the Valence, Arousal and Dominance.
fileConn<-file("input.txt")
writeLines(export$paragraph[i], fileConn)
system("java -jar  /home/expectopatronum/Desktop/thesis/thesis/JEmAS-v0.2-beta.jar  /home/expectopatronum/Desktop/thesis/thesis/input.txt > output.csv", intern=TRUE)
close(fileConn)
temp_kb_g2 <- read.csv("output.csv")
temp_kb_g2 <- read.csv("output.csv", sep = "\t")
export$Valence[i] = temp_kb_g2$Valence[1]
export$Arousal[i] = temp_kb_g2$Arousal[1]
export$Dominance[i] = temp_kb_g2$Dominance[1]
}
#Plotting along the storyline
#plot(export$nrc_sentiment,xlab = "Event Indexes", ylab = "Emotion Valence", main = "Emotion valence along different events throughout the story ",type = "l")

write.csv(export, file= "thesis_test_score.csv", row.names = FALSE)

#fileConn<-file("events.txt")
#writeLines(as.character(event), fileConn)
#close(fileConn)

#Run only if test file is created
kb_g2 = read.csv("thesis_g2.csv")  #read csv file















