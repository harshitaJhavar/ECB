#Script for Goal 1 by Harshita Jhavar
#Creating Story Graph from knowledge base and querying it
setwd("/home/expectopatronum/Desktop/thesis/thesis")
kb_g1 = read.csv("Final_goal1.csv")  # read csv file
kb_g2 = read.csv("thesis_g2.csv")  # read csv file
kb_original = read.csv("td_no_labels.csv")  # read csv file
kb_test = read.csv("thesis_g2_test.csv") #read csv file for sentences
kb_test_final = read.csv("thesis_test_score.csv")

#Loading the libraries
library(dplyr)
library(tidyverse)

#Exploratory analysis of data in the data frame to combine the different categories to Happy, Sad, Angry, Other.

#Adding up the scores
#Training Input 
kb_g1$happy_score = kb_g1$joy + kb_g1$trust + kb_g1$surprise
kb_g1$anger_score = kb_g1$anger + kb_g1$disgust
kb_g1$sad_score = kb_g1$sadness
kb_g1$others_score = kb_g1$anticipation 

#Test Input
kb_test_final$happy_score = kb_test_final$joy + kb_test_final$trust + kb_test_final$surprise
kb_test_final$anger_score = kb_test_final$anger + kb_test_final$disgust
kb_test_final$sad_score = kb_test_final$sadness
kb_test_final$others_score = kb_test_final$anticipation 

#Removing the 7 emotion category scores and creating a new data frame for training including the associated actions
kb_train = data.frame(kb_g1$paragraph, kb_g1$happy_score, kb_g1$anger_score, kb_g1$sad_score, kb_g1$others_score, kb_g1$nrc_sentiment,kb_g1$Valence, kb_g1$Arousal, kb_g1$Dominance, kb_g2$Subject.Characters, kb_g2$Actions.with.Subject.Charcater, kb_g2$Object.Characters, kb_g2$Objects.and.Actions, kb_g1$True.Label)

#Removing the paragraph column and adding a new data frame to train the model according to emocontext script
norm_div <- kb_g1$happy_score + kb_g1$anger_score + kb_g1$sad_score + kb_g1$others_score
#kb_g3 <- data.frame(kb_original$id, kb_original$turn1, kb_original$turn2, kb_original$turn3, kb_g1$happy_score/norm_div, kb_g1$anger_score/norm_div, kb_g1$sad_score/norm_div, kb_g1$others_score/norm_div, kb_g1$nrc_sentiment,kb_g1$Valence, kb_g1$Arousal, kb_g1$Dominance, kb_g2$Subject.Characters, kb_g2$Actions.with.Subject.Charcater, kb_g2$Object.Characters, kb_g2$Objects.and.Actions, kb_g1$True.Label)

kb_g3 <- data.frame(kb_original$id, kb_original$turn1, kb_original$turn2, kb_original$turn3, 
                    kb_g1$happy_score/norm_div, kb_g1$anger_score/norm_div, 
                    kb_g1$sad_score/norm_div, kb_g1$others_score/norm_div, 
                    kb_g1$nrc_sentiment, kb_g1$True.Label)
kb_g3[is.na(kb_g3)] <- 0
norm_div_test <- kb_test_final$happy_score + kb_test_final$anger_score + kb_test_final$sad_score + kb_test_final$others_score

#Setting up current test file
kb_current_test <- data.frame(kb_test$id, kb_test$turn1, kb_test$turn2, kb_test$turn3, 
                              kb_test_final$happy_score/norm_div_test, kb_test_final$anger_score/norm_div_test, 
                              kb_test_final$sad_score/norm_div_test, kb_test_final$others_score/norm_div_test, 
                              kb_test_final$nrc_sentiment)

kb_current_test[is.na(kb_current_test)] <- 0
#Exporting the goal 3 corpus to text file
write.table(kb_g3, file = "/home/expectopatronum/Desktop/emoContext/starterkitdata/train5.txt", 
            append = FALSE, sep = "\t", row.names=FALSE, quote=FALSE, fileEncoding = "UTF-8")
#Exporting the goal 3 corpus to text file
write.table(kb_current_test, file = "/home/expectopatronum/Desktop/emoContext/starterkitdata/test5.txt", 
            append = FALSE, sep = "\t", row.names=FALSE, quote=FALSE, fileEncoding = "UTF-8")

#Fitting the k-means
fit <- kmeans(kb_g3[5:9], 5)

